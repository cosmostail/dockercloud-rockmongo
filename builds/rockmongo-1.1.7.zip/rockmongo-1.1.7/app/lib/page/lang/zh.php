<?php
/**
 * zh_cn的配置
 * 
 * @since 1.0
 * @package if
 * @subpackage plugin.pager.lang
 */
$message["pager_prev"] = "上一页";
$message["pager_next"] = "下一页";
$message["pager_first"] = "首页";
$message["pager_last"] = "尾页";
$message["pager_input_pageno"] = "输入页数";
$message["pager_current_pageno"] = "第 %d 页";
$message["pager_total_page"] = "共 %d 页";

?>