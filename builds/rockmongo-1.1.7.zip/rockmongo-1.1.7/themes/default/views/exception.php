<blockquote>
	<span class="error"><?php h($message) ?></span>
</blockquote>